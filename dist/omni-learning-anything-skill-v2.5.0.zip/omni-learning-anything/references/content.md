# Teaching and evidence contract

## Curriculum
For vague/broad requests first use [intent.md](intent.md). Preserve explicit user intent, label assumptions, distinguish necessary prerequisites from enrichment, and map the ordered modules/days to observable outcomes. A plan should make its interpretation and boundaries visible. Concise but specific goals do not require expanding into an entire field. Check relevance, prerequisite order, examples and coherence rather than rewarding length or a large topic count.

Ask what the learner should be able to explain, distinguish or do. Divide the total duration into prerequisite-ordered phases. Every day gets a topic and a concrete output. Include retrieval practice and synthesis (e.g. every fifth day); review frequency is a design choice, not a claim of universal scientific optimality. A short course establishes a framework, not expertise in an entire field.

Choose the subject's natural forms of evidence and practice:
- Technology: systems, mechanisms, measurements, limits and societal choices.
- Economics/finance: opportunity costs, models and assumptions, data definitions and counterexamples. Educational cases are not personalized investment instructions.
- History: chronology, provenance, primary/secondary sources, competing explanations and evidential limits. Do not invent quotations or motives.
- Architecture: plan/elevation/section, material/structure/use, dated works and urban context. Images may illustrate but cannot prove a reconstruction.
- Music: listening, rhythm, pitch, timbre, form and cultural context. Western theory is one framework, not a universal description of all music.
- Career study: realistic decisions, cases and practice answers; never invent real interview questions, personal accomplishments or openings.

## Plan document
Include learner brief and boundaries; outcomes; schedule and workload; visual overview; each day's topic/objective and periodic review; assessment and revision method; >=5 useful expansion links. Plan confirmation is distinct from delivery of Day01.

## Daily document
Suggested structure: navigation/goal; recall and motivating question; 2–3 concepts; worked example with assumptions; short practice with self-check; recap and next step. Adapt headings to subject. Word count is a diagnostic, not the objective. For 10–15 minutes, budget approximately 7–10 minutes reading/figure study plus 2–5 minutes practice. Time real reading during QA if possible, otherwise disclose estimate.

Short checks: reserve their time inside the practice allowance and use [assessment](assessment.md). Default to choice, brief explanation or short discussion; avoid long writing, actual programming/operations, experiments and projects unless the learner explicitly requested such practical training. A programming subject alone is insufficient. Keep private short-test answers separate from visible worked examples/self-check solutions. Add a localized invitation to return to the agent and request a check, without scheduling a later quiz or reminder.

## Selected-material courses

When config contains `materials`, [materials](materials.md) governs source scope and provenance. Use exact selected versions/units and original locators. Strict mode permits only bound material evidence; material-first mode requires it while labeling permitted supplements. Such documents need actual core sources, not five unrelated external links; the five-link rule below applies to courses without material settings. A stable private source version is re-read locally, not falsely described as freshly fetched online. Keep teaching figures useful and distinguish original material from constructions; no OCR/media comprehension is inferred.

## Research
Actually search the web and open sources for every plan/lesson. Favor original institutions, research papers, museum collections, scholarly editions, official stats and named expert authors. Topic diversity matters more than brand quotas. Latest is required for unstable claims; original older material may be best for established knowledge. Open the extension links too; five links to one irrelevant homepage do not qualify. Use specific pages with recommended section/activity. Mark paywalls or access limits. If content cannot be read, it cannot support a verified factual claim.

Use [S1] inline identifiers and matching source records: title, URL, publisher, publication date ("未标注" when genuinely unknown), checked_at ISO date, recommendation/evidence note. Fact, interpretation, simplified teaching model and hypothetical example must remain distinguishable. Keep paraphrases original; do not copy large source passages. Failure of search or source verification is not a successful new lesson.

## Images
Every document needs at least one pedagogical figure and its in-text explanation. Plan visuals orient the course; lesson visuals answer a specific question. Reusing a multi-panel figure is acceptable if each lesson explicitly studies a different relevant panel. AI illustrations require real model generation, prompt provenance and a disclosure; check factual and visual errors. No AI-generated image is a primary historical source. For redistributed source images document permission/license independently of the code license. Do not bundle proprietary fonts.

## Acceptance
Inspect every page or the entire native rendered document at useful resolution. Check text, diagrams, captions, flow and clickable links; PDF additionally checks embedded fonts and LaTeX warnings. Markdown must resolve asset references; DOCX must embed them; cloud documents must have uploaded media and real readback. Save the actual inspection note. Content and visual inspection cannot be inferred from a successful exit code. User reading and mastery remain unknown unless the user supplies feedback.
